let images=document.getElementsByTagName('img');
let path="images/tokisaki_kurumi_";
let files=[];
for(let i=1;i<8;i++){
	files.push(i+'.jpg');
}
for(let image of images){
	let index = Math.floor(Math.random()*files.length);
	image.src = browser.extension.getURL(path+files[index]);
}